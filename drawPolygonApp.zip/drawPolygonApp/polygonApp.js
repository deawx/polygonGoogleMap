var mapApp = angular.module('PolygonMapApp', []);
mapApp.controller('MapController', ['$scope', 'PolygonValueModel', function ($scope, PolygonValueModel) {
    var mapCtrl = this;
    
    var drawingOptions = PolygonValueModel.drawingOptions;
    var polygonContainer = PolygonValueModel.polygonContainer;
    
    var map = new google.maps.Map(document.getElementById('map'), {
      center: {lat: 25, lng: 120},
      zoom: 4
    });

    var drawingManager = new google.maps.drawing.DrawingManager(drawingOptions);
    
    google.maps.event.addListener(drawingManager, 'polygoncomplete', function(polygon) {
        var path = polygon.getPath();
        polygonContainer.push(polygon);
        console.info("Polygon path--->", path);
       
        for(var index = 0; index < polygonContainer.length; index++){
            var storedPolygonObj = polygonContainer[index];
            console.info(storedPolygonObj);
            path.forEach(function(polygonElement, index){
                console.info(polygonElement);
                console.log("Latitude :", polygonElement.toString());
                console.log("Longitude :", polygonElement.toString());
                if(google.maps.geometry.poly.containsLocation(polygonElement, storedPolygonObj)){
                    console.info("Polygon intersects");
                } else {
                    console.info("Polygon does not intersects");
                }
            });
            
        }
    });
    
    drawingManager.setMap(map);
}]);