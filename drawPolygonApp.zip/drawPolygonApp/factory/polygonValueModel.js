mapApp.factory('PolygonValueModel', [ function(){
    
    var polygonValueModel = this;
    
    polygonValueModel.drawingOptions = {
      drawingMode: google.maps.drawing.OverlayType.MARKER,
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        drawingModes: ['polygon']
      }
    };
    
    polygonValueModel.polygonContainer = [];
    
    return polygonValueModel;
}]);