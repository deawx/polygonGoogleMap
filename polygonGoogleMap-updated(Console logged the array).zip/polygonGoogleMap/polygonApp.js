var mapApp = angular.module('PolygonMapApp', []);
mapApp.controller('MapController', ['$scope', 'PolygonValueModel', function ($scope, PolygonValueModel) {

    var mapOptions = PolygonValueModel.mapOptions;
    var polygonPoints = PolygonValueModel.polygonPoints;
    var polygonPoints2 = PolygonValueModel.polygonPoints2;
    
    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    var infoWindow = new google.maps.InfoWindow();
     
    var createPolygon = function (polygonAttributes) {
        console.info("Polygon Array - ", polygonAttributes);
        var polygon = new google.maps.Polygon({
          paths: polygonAttributes,
          strokeColor: '#FF0000',
        });
        
        polygon.setMap($scope.map);
    }

    
    createPolygon(polygonPoints);
    createPolygon(polygonPoints2);

}]);