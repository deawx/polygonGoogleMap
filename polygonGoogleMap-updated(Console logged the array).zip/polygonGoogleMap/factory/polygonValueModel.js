mapApp.factory('PolygonValueModel', [ function(){
    
    var polygonValueModel = this;
    polygonValueModel.mapOptions = {
      zoom: 4,
      center: new google.maps.LatLng(25,80),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    
    polygonValueModel.polygonPoints = [
        {
            lat : 35.8617,
            lng : 104.1954
        },
        {
            lat : 39.9042,
            lng : 116.4074
        },
        {
            lat : 36.2048,
            lng : 138.2529
        },
        {
            lat : 12.8797,
            lng : 121.7740
        },
        {
            lat : 14.0583,
            lng : 108.2772
        },
    ];
    
    polygonValueModel.polygonPoints2 = [
        {
            lat : 31.2304,
            lng : 121.4737
        },
        {
            lat : 25.0330,
            lng : 121.5654
        },
        {
            lat : 22.3964,
            lng : 114.1095
        }
    ];
    
    return polygonValueModel;
}]);